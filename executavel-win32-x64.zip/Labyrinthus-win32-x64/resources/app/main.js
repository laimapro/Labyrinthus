const { app, BrowserWindow } = require('electron');

var mainWindow = null;

async function createWindow() {
    mainWindow = new BrowserWindow({});
    mainWindow.maximize();
    mainWindow.setMenu(null); // Remover o menu superior
    await mainWindow.loadFile('src/pages/index.html');
}

app.whenReady().then(createWindow);
